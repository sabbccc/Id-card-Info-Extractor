import json

str = ' he is my naukar'

f = open('email.json','w')

f.write(str)