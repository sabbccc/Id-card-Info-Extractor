# Document-Scanner-Using-OpenCV-Python
Building a document scanner with OpenCV, In this blog post I showed you how to build a mobile document scanner using OpenCV
