import json

str = ' he is my  kickass chika'

f = open('email.json','w')

f.write(str)