import re

'''
f = open('email.txt', 'r')
contents =f.read()
#contents = ' hello my nam eis aniruch@getmorph.com'

for email in contents.split(' '):
    #print(email)
    match = re.findall(r"[a-z0-9\.\-+_]+@[a-z0-9\.\-+_]+\.[a-z]+", email)
    if match != None:
	    print('EMAIL:' + email)
        '''
